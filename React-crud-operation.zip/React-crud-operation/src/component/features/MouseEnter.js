import React from 'react'

const MouseEnter = () => {
  return (
    <div>MouseEnter</div>
  )
}

export default MouseEnter