import React from 'react'
import Redux2 from './Redux2'

function Redux1() {
  return (
    <div>
      <Redux2/>
    </div>
  )
}

export default Redux1
